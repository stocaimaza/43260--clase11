/* PASOS PARA CREAR EL CONTEXT.JS*/

import React from 'react';

export const Contexto = React.createContext(null);

//1)Crear el contexto y darle un valor por default. 
//2) Importar el contexto en la App.
//3) Proveer el contexto en el componente App. 
//4) Consumir el contexto en el componente Hijo. 