import Hijo from "../Hijo/Hijo"

const Padre = ({herencia}) => {
  return (
    <div>
        <Hijo herencia = {herencia} />
    </div>
  )
}

export default Padre