//UTILIZANDO PROPS

// const Hijo = ({herencia}) => {
//   return (
//     <div>
//         <p>Mi herencia en efectivo es de:  {herencia.efectivo} </p>
//         <p>Choque estos vehiculos: {herencia.vehiculos} </p>
//         <p>Y estoy usando estas propiedades: {herencia.propiedades} </p>
//     </div>
//   )
// }

// export default Hijo


//UTILIZANDO EL CONSUMER: 

// import React from 'react';
// import { Contexto } from '../../context/context';

// const Hijo = () => {
//   return (
//     <Contexto.Consumer>
//         {/* Para poder acceder a la información se usa una función de renderizado */}

//         {
//             (herencia) => (
//                 <div>
//                     <p>Mi herencia es: {herencia.efectivo} </p>
//                     <p>Recibí estos autos: {herencia.vehiculos} </p>
//                     <p>Y ya vendí estas propiedades: {herencia.propiedades} </p>
//                 </div>
//             )
//         }
//     </Contexto.Consumer>
//   )
// }

// export default Hijo

//UTILIZAMOS UN ROBIN HOOK "USECONTEXT"

//En lugar de usar el Consumer y una función de renderizado yo puedo utilizar un Hook llamado "useContext"

//1) Importamos el Hook
import { useContext } from "react";

//2) Importamos el Contexto: 
import { Contexto } from "../../context/context";

const Hijo = () => {

    //3) Creamos una variable que almacene el valor del contexto:
    const herencia = useContext(Contexto);

  return (
    <div>
        <p>Efectivo: {herencia.efectivo} </p>
        <p>Autos: {herencia.vehiculos} </p>
        <p>Casas: {herencia.propiedades} </p>
    </div>
  )
}

export default Hijo

