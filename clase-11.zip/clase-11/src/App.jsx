//Aprendimos en estas clases que podemos enviar información entre componentes a traves de las props. Pero que estas se envian de forma unidireccional de un componente padre a un componente hijo. 
//Esto en aplicaciones grandes con muchas capas de componentes se convierte en una tarea tediosa. 


//EJEMPLO: HERENCIA FAMILIAR. 
import Abuelo from "./componentes/Abuelo/Abuelo"


//Usando CONTEXT:

import { Contexto } from "./context/context";


const App = () => {
  
  const herencia = {
    efectivo: 100000000,
    propiedades: 10,
    vehiculos: 20
  }

  return (
    <div>
      <Contexto.Provider value={herencia}>
        <Abuelo />
      </Contexto.Provider> 
    </div>
    //En el value paso la información que quiero transferir. 
  )
}

export default App